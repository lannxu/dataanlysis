﻿# 人才盘点实时投票工具
运行 `pnpm start`。后台：http://localhost:3000/admin.html。手机与电脑连接同一 Wi-Fi，扫描后台二维码即可评估。
